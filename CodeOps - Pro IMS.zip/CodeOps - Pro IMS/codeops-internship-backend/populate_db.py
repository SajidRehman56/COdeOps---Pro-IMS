#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.models.user import User, db
from src.models.task import Task
from src.models.user_task_progress import UserTaskProgress

def populate_database():
    with app.app_context():
        # Create admin user
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@codeops-pro.com',
                full_name='Admin User',
                role='admin'
            )
            admin.set_password('Admin123!')
            db.session.add(admin)
            print("Created admin user: admin / Admin123!")
        
        # Web Development Tasks
        web_tasks = [
            {
                'title': 'HTML Fundamentals',
                'description': 'Create a basic HTML page with proper structure, semantic elements, and forms. Include headers, paragraphs, lists, links, and a contact form.',
                'order_index': 1,
                'points': 10,
                'estimated_hours': 2,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'CSS Styling and Layout',
                'description': 'Style your HTML page using CSS. Implement flexbox or grid layout, responsive design, and modern CSS features like animations and transitions.',
                'order_index': 2,
                'points': 15,
                'estimated_hours': 3,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'JavaScript Interactivity',
                'description': 'Add JavaScript functionality to your webpage. Implement form validation, DOM manipulation, event handling, and local storage.',
                'order_index': 3,
                'points': 20,
                'estimated_hours': 4,
                'difficulty_level': 'intermediate'
            },
            {
                'title': 'React Component Development',
                'description': 'Build a React application with multiple components, state management, props, and hooks. Create a todo list or simple dashboard.',
                'order_index': 4,
                'points': 25,
                'estimated_hours': 6,
                'difficulty_level': 'intermediate'
            },
            {
                'title': 'API Integration',
                'description': 'Integrate your React app with a REST API. Implement CRUD operations, error handling, and loading states.',
                'order_index': 5,
                'points': 30,
                'estimated_hours': 5,
                'difficulty_level': 'advanced'
            }
        ]
        
        # DevOps Tasks
        devops_tasks = [
            {
                'title': 'Linux Command Line Basics',
                'description': 'Demonstrate proficiency with Linux commands. Create scripts for file management, process monitoring, and system administration.',
                'order_index': 1,
                'points': 10,
                'estimated_hours': 2,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'Git Version Control',
                'description': 'Set up a Git repository, demonstrate branching, merging, and collaboration workflows. Include proper commit messages and documentation.',
                'order_index': 2,
                'points': 15,
                'estimated_hours': 3,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'Docker Containerization',
                'description': 'Create Docker containers for a web application. Write Dockerfiles, use docker-compose, and demonstrate container orchestration.',
                'order_index': 3,
                'points': 25,
                'estimated_hours': 5,
                'difficulty_level': 'intermediate'
            },
            {
                'title': 'CI/CD Pipeline Setup',
                'description': 'Set up a continuous integration and deployment pipeline using GitHub Actions or Jenkins. Include automated testing and deployment.',
                'order_index': 4,
                'points': 30,
                'estimated_hours': 6,
                'difficulty_level': 'advanced'
            },
            {
                'title': 'Infrastructure as Code',
                'description': 'Use Terraform or similar tools to provision cloud infrastructure. Demonstrate infrastructure automation and best practices.',
                'order_index': 5,
                'points': 35,
                'estimated_hours': 8,
                'difficulty_level': 'advanced'
            }
        ]
        
        # Mobile App Development Tasks
        mobile_tasks = [
            {
                'title': 'Mobile UI Design Principles',
                'description': 'Create wireframes and mockups for a mobile app. Demonstrate understanding of mobile UX principles and design patterns.',
                'order_index': 1,
                'points': 10,
                'estimated_hours': 3,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'React Native Setup',
                'description': 'Set up React Native development environment. Create a basic app with navigation and multiple screens.',
                'order_index': 2,
                'points': 15,
                'estimated_hours': 4,
                'difficulty_level': 'beginner'
            },
            {
                'title': 'State Management and Navigation',
                'description': 'Implement state management using Redux or Context API. Create complex navigation flows with React Navigation.',
                'order_index': 3,
                'points': 20,
                'estimated_hours': 5,
                'difficulty_level': 'intermediate'
            },
            {
                'title': 'Native Features Integration',
                'description': 'Integrate native device features like camera, GPS, push notifications, and local storage in your mobile app.',
                'order_index': 4,
                'points': 25,
                'estimated_hours': 6,
                'difficulty_level': 'intermediate'
            },
            {
                'title': 'App Store Deployment',
                'description': 'Prepare your app for production deployment. Create app store listings, handle app signing, and demonstrate the deployment process.',
                'order_index': 5,
                'points': 30,
                'estimated_hours': 4,
                'difficulty_level': 'advanced'
            }
        ]
        
        # Add tasks for each field
        for field, tasks in [('web_dev', web_tasks), ('devops', devops_tasks), ('mobile_dev', mobile_tasks)]:
            for task_data in tasks:
                existing_task = Task.query.filter_by(
                    title=task_data['title'],
                    internship_field=field
                ).first()
                
                if not existing_task:
                    task = Task(
                        internship_field=field,
                        **task_data
                    )
                    db.session.add(task)
                    print(f"Created task: {task_data['title']} for {field}")
        
        db.session.commit()
        print("Database populated successfully!")

if __name__ == '__main__':
    populate_database()

