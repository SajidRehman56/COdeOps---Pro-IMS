from src.models.user import db
from datetime import datetime
import uuid

class Certificate(db.Model):
    __tablename__ = "certificates"
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    certificate_id = db.Column(db.String(100), unique=True, nullable=False)  # Unique certificate ID
    internship_field = db.Column(db.String(50), nullable=False)
    issue_date = db.Column(db.DateTime, default=datetime.utcnow)
    completion_date = db.Column(db.DateTime, default=datetime.utcnow)
    total_points = db.Column(db.Integer, default=0)
    total_tasks_completed = db.Column(db.Integer, default=0)
    file_path = db.Column(db.String(500))  # Path to generated PDF certificate
    qr_code_data = db.Column(db.Text)  # QR code verification data
    is_verified = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __init__(self, **kwargs):
        super(Certificate, self).__init__(**kwargs)
        if not self.certificate_id:
            self.certificate_id = f"CODEOPS-{self.internship_field.upper()}-{str(uuid.uuid4())[:8]}"

    def __repr__(self):
        return f'<Certificate {self.certificate_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'certificate_id': self.certificate_id,
            'internship_field': self.internship_field,
            'completion_date': self.completion_date.isoformat() if self.completion_date else None,
            'total_points': self.total_points,
            'total_tasks_completed': self.total_tasks_completed,
            'file_path': self.file_path,
            'qr_code_data': self.qr_code_data,
            'is_verified': self.is_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

