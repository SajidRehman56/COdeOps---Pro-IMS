from src.models.user import db

class UserTaskProgress(db.Model):
    __tablename__ = "user_task_progress"

    id = db.Column(db.Integer, primary_key=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    task_id = db.Column(db.Integer, db.ForeignKey("tasks.id"))
    status = db.Column(db.String, default="not_started") # not_started, in_progress, submitted, approved, rejected
    started_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)

    user = db.relationship("User", back_populates="task_progress")
    task = db.relationship("Task", back_populates="user_progress")


