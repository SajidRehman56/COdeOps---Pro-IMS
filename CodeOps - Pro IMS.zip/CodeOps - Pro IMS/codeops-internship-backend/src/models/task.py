from src.models.user import db
from datetime import datetime

class Task(db.Model):
    __tablename__ = "tasks"
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    internship_field = db.Column(db.String(50), nullable=False)  # 'web_dev', 'devops', 'mobile_dev'
    difficulty_level = db.Column(db.String(20), default='beginner')  # 'beginner', 'intermediate', 'advanced'
    order_index = db.Column(db.Integer, nullable=False)  # Order of tasks in the program
    points = db.Column(db.Integer, default=10)  # XP points for gamification
    estimated_hours = db.Column(db.Integer, default=1)
    requirements = db.Column(db.Text)  # JSON string of requirements
    resources = db.Column(db.Text)  # JSON string of helpful resources
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    submissions = db.relationship("Submission", backref="task", lazy=True)
    user_progress = db.relationship("UserTaskProgress", back_populates="task", lazy=True)
    def __repr__(self):
        return f'<Task {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'internship_field': self.internship_field,
            'difficulty_level': self.difficulty_level,
            'order_index': self.order_index,
            'points': self.points,
            'estimated_hours': self.estimated_hours,
            'requirements': self.requirements,
            'resources': self.resources,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_active': self.is_active
        }

