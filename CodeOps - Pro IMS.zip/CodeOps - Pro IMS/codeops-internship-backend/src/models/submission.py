from src.models.user import db
from datetime import datetime

class Submission(db.Model):
    __tablename__ = "submissions"
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey("tasks.id"), nullable=False)
    submission_text = db.Column(db.Text)
    file_path = db.Column(db.String(500))  # Path to uploaded file
    video_link = db.Column(db.String(500))  # Optional video demonstration link
    status = db.Column(db.String(20), default="pending")  # "pending", "approved", "rejected", "needs_revision"
    admin_feedback = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)
    reviewed_by = db.Column(db.Integer, db.ForeignKey("users.id"))  # Admin who reviewed
    points_earned = db.Column(db.Integer, default=0)
    
    # Unique constraint to prevent multiple submissions per user per task
    __table_args__ = (db.UniqueConstraint("user_id", "task_id", name="unique_user_task_submission"),)

    def __repr__(self):
        return f'<Submission {self.id} - User {self.user_id} - Task {self.task_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'task_id': self.task_id,
            'submission_text': self.submission_text,
            'file_path': self.file_path,
            'video_link': self.video_link,
            'status': self.status,
            'admin_feedback': self.admin_feedback,
            'submitted_at': self.submitted_at.isoformat() if self.submitted_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'reviewed_by': self.reviewed_by,
            'points_earned': self.points_earned
        }

