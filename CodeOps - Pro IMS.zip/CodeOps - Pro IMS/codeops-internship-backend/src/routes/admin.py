from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.task import Task
from src.models.submission import Submission
from src.models.certificate import Certificate
from src.models.user_task_progress import UserTaskProgress
from datetime import datetime
import json

admin_bp = Blueprint("admin", __name__)

def admin_required(f):
    """Decorator to require admin role"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        if not user or user.role != "admin":
            return jsonify({"error": "Admin access required"}), 403
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route("/dashboard", methods=["GET"])
@jwt_required()
@admin_required
def get_dashboard():
    try:
        # Get statistics
        total_students = User.query.filter_by(role="student").count()
        total_tasks = Task.query.filter_by(is_active=True).count()
        total_submissions = Submission.query.count()
        pending_submissions = Submission.query.filter_by(status="pending").count()
        approved_submissions = Submission.query.filter_by(status="approved").count()
        total_certificates = Certificate.query.count()
        
        # Get field-wise statistics
        field_stats = {}
        for field in ["web_dev", "devops", "mobile_dev"]:
            students_count = User.query.filter_by(role="student", internship_field=field).count()
            tasks_count = Task.query.filter_by(internship_field=field, is_active=True).count()
            field_stats[field] = {
                "students": students_count,
                "tasks": tasks_count
            }
        
        # Get recent submissions
        recent_submissions = Submission.query.order_by(Submission.submitted_at.desc()).limit(10).all()
        recent_submissions_data = []
        for sub in recent_submissions:
            user = User.query.get(sub.user_id)
            task = Task.query.get(sub.task_id)
            sub_dict = sub.to_dict()
            sub_dict["user_name"] = user.full_name if user else "Unknown"
            sub_dict["task_title"] = task.title if task else "Unknown"
            recent_submissions_data.append(sub_dict)
        
        return jsonify({
            "total_students": total_students,
            "total_tasks": total_tasks,
            "total_submissions": total_submissions,
            "pending_submissions": pending_submissions,
            "approved_submissions": approved_submissions,
            "total_certificates": total_certificates,
            "field_statistics": field_stats,
            "recent_submissions": recent_submissions_data
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/students", methods=["GET"])
@jwt_required()
@admin_required
def get_students():
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        field = request.args.get("field")
        
        query = User.query.filter_by(role="student")
        
        if field:
            query = query.filter_by(internship_field=field)
        
        students = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        students_data = []
        for student in students.items:
            student_dict = student.to_dict()
            
            # Get progress info using UserTaskProgress
            total_tasks = Task.query.filter_by(
                internship_field=student.internship_field,
                is_active=True
            ).count()
            
            completed_tasks = UserTaskProgress.query.filter_by(
                user_id=student.id,
                status="approved"
            ).count()
            
            in_progress_tasks = UserTaskProgress.query.filter_by(
                user_id=student.id,
                status="in_progress"
            ).count()

            submitted_tasks = UserTaskProgress.query.filter_by(
                user_id=student.id,
                status="submitted"
            ).count()
            
            total_points = db.session.query(db.func.sum(Submission.points_earned)).filter_by(
                user_id=student.id,
                status="approved"
            ).scalar() or 0
            
            student_dict["progress"] = {
                "total_tasks": total_tasks,
                "completed_tasks": completed_tasks,
                "in_progress_tasks": in_progress_tasks,
                "submitted_tasks": submitted_tasks,
                "not_started_tasks": total_tasks - completed_tasks - in_progress_tasks - submitted_tasks,
                "total_points": total_points,
                "progress_percentage": (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
            }
            
            students_data.append(student_dict)
        
        return jsonify({
            "students": students_data,
            "pagination": {
                "page": students.page,
                "pages": students.pages,
                "per_page": students.per_page,
                "total": students.total
            }
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/submissions", methods=["GET"])
@jwt_required()
@admin_required
def get_all_submissions():
    try:
        page = request.args.get("page", 1, type=int)
        per_page = request.args.get("per_page", 20, type=int)
        status = request.args.get("status")
        field = request.args.get("field")
        
        query = Submission.query
        
        if status:
            query = query.filter_by(status=status)
        
        if field:
            # Join with User to filter by internship field
            query = query.join(User).filter(User.internship_field == field)
        
        submissions = query.order_by(Submission.submitted_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        submissions_data = []
        for sub in submissions.items:
            user = User.query.get(sub.user_id)
            task = Task.query.get(sub.task_id)
            sub_dict = sub.to_dict()
            sub_dict["user"] = user.to_dict() if user else None
            sub_dict["task"] = task.to_dict() if task else None
            submissions_data.append(sub_dict)
        
        return jsonify({
            "submissions": submissions_data,
            "pagination": {
                "page": submissions.page,
                "pages": submissions.pages,
                "per_page": submissions.per_page,
                "total": submissions.total
            }
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/submissions/<int:submission_id>/review", methods=["POST"])
@jwt_required()
@admin_required
def review_submission(submission_id):
    try:
        admin_id = get_jwt_identity()
        data = request.get_json()
        
        if not data.get("status") or data["status"] not in ["approved", "rejected", "needs_revision"]:
            return jsonify({"error": "Valid status is required"}), 400
        
        submission = Submission.query.get(submission_id)
        if not submission:
            return jsonify({"error": "Submission not found"}), 404
        
        submission.status = data["status"]
        submission.admin_feedback = data.get("feedback", "")
        submission.reviewed_at = datetime.utcnow()
        submission.reviewed_by = admin_id
        
        # Update UserTaskProgress status based on submission review
        user_task_progress = UserTaskProgress.query.filter_by(
            user_id=submission.user_id,
            task_id=submission.task_id
        ).first()

        if not user_task_progress:
            # This should ideally not happen if tasks are started correctly
            user_task_progress = UserTaskProgress(
                user_id=submission.user_id,
                task_id=submission.task_id,
                status=submission.status,
                started_at=datetime.utcnow(), # Assuming it was started if being reviewed
                completed_at=datetime.utcnow()
            )
            db.session.add(user_task_progress)
        else:
            user_task_progress.status = submission.status
            user_task_progress.completed_at = datetime.utcnow()

        # Award points if approved
        if data["status"] == "approved":
            task = Task.query.get(submission.task_id)
            if task:
                submission.points_earned = task.points
            
            # Check if all tasks are completed for the user in this field
            user = User.query.get(submission.user_id)
            if user:
                total_tasks_in_field = Task.query.filter_by(
                    internship_field=user.internship_field,
                    is_active=True
                ).count()
                
                approved_tasks_in_field = UserTaskProgress.query.filter_by(
                    user_id=user.id,
                    status="approved"
                ).count()

                if total_tasks_in_field > 0 and approved_tasks_in_field == total_tasks_in_field:
                    # All tasks approved, generate certificate
                    existing_certificate = Certificate.query.filter_by(
                        user_id=user.id,
                        internship_field=user.internship_field
                    ).first()
                    if not existing_certificate:
                        certificate = Certificate(
                            user_id=user.id,
                            internship_field=user.internship_field,
                            issue_date=datetime.utcnow()
                        )
                        db.session.add(certificate)
                        db.session.commit() # Commit here to get certificate ID
                        # TODO: Generate PDF certificate and store path
                        # For now, just create the record
                        print(f"Certificate generated for {user.full_name} in {user.internship_field}")
        else:
            submission.points_earned = 0
        
        db.session.commit()
        
        return jsonify({
            "message": "Submission reviewed successfully",
            "submission": submission.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/tasks", methods=["GET"])
@jwt_required()
@admin_required
def get_all_tasks():
    try:
        field = request.args.get("field")
        
        query = Task.query
        if field:
            query = query.filter_by(internship_field=field)
        
        tasks = query.order_by(Task.internship_field, Task.order_index).all()
        
        return jsonify({
            "tasks": [task.to_dict() for task in tasks]
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/tasks", methods=["POST"])
@jwt_required()
@admin_required
def create_task():
    try:
        data = request.get_json()
        
        required_fields = ["title", "description", "internship_field", "order_index"]
        for field in required_fields:
            if not data.get(field):
                return jsonify({"error": f"{field} is required"}), 400
        
        # Validate internship field
        if data["internship_field"] not in ["web_dev", "devops", "mobile_dev"]:
            return jsonify({"error": "Invalid internship field"}), 400
        
        task = Task(
            title=data["title"],
            description=data["description"],
            internship_field=data["internship_field"],
            difficulty_level=data.get("difficulty_level", "beginner"),
            order_index=data["order_index"],
            points=data.get("points", 10),
            estimated_hours=data.get("estimated_hours", 1),
            requirements=data.get("requirements"),
            resources=data.get("resources")
        )
        
        db.session.add(task)
        db.session.commit()
        
        return jsonify({
            "message": "Task created successfully",
            "task": task.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/tasks/<int:task_id>", methods=["PUT"])
@jwt_required()
@admin_required
def update_task(task_id):
    try:
        task = Task.query.get(task_id)
        if not task:
            return jsonify({"error": "Task not found"}), 404
        
        data = request.get_json()
        
        # Update fields
        if "title" in data:
            task.title = data["title"]
        if "description" in data:
            task.description = data["description"]
        if "difficulty_level" in data:
            task.difficulty_level = data["difficulty_level"]
        if "order_index" in data:
            task.order_index = data["order_index"]
        if "points" in data:
            task.points = data["points"]
        if "estimated_hours" in data:
            task.estimated_hours = data["estimated_hours"]
        if "requirements" in data:
            task.requirements = data["requirements"]
        if "resources" in data:
            task.resources = data["resources"]
        if "is_active" in data:
            task.is_active = data["is_active"]
        
        task.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            "message": "Task updated successfully",
            "task": task.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@admin_bp.route("/tasks/<int:task_id>", methods=["DELETE"])
@jwt_required()
@admin_required
def delete_task(task_id):
    try:
        task = Task.query.get(task_id)
        if not task:
            return jsonify({"error": "Task not found"}), 404
        
        # Soft delete - just mark as inactive
        task.is_active = False
        db.session.commit()
        
        return jsonify({"message": "Task deleted successfully"}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


