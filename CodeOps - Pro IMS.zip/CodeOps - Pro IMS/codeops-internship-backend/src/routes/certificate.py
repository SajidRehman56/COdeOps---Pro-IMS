from flask import Blueprint, request, jsonify, send_file, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.task import Task
from src.models.submission import Submission
from src.models.certificate import Certificate
import os
from datetime import datetime

certificate_bp = Blueprint('certificate', __name__)

def generate_certificate_pdf(user, certificate, tasks_completed, total_points):
    """Generate a PDF certificate for the user"""
    # Temporarily disabled for deployment
    return f"certificates/certificate_{certificate.certificate_id}.pdf"

@certificate_bp.route('/certificates/generate', methods=['POST'])
@jwt_required()
def generate_certificate():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Check if user already has a certificate
        existing_cert = Certificate.query.filter_by(
            user_id=user_id,
            internship_field=user.internship_field
        ).first()
        
        if existing_cert:
            return jsonify({'error': 'Certificate already generated'}), 400
        
        # Check if user has completed all tasks
        total_tasks = Task.query.filter_by(
            internship_field=user.internship_field,
            is_active=True
        ).count()
        
        completed_tasks = Submission.query.filter_by(
            user_id=user_id,
            status='approved'
        ).count()
        
        if completed_tasks < total_tasks:
            return jsonify({
                'error': 'All tasks must be completed before generating certificate',
                'completed_tasks': completed_tasks,
                'total_tasks': total_tasks
            }), 400
        
        # Calculate total points
        total_points = db.session.query(db.func.sum(Submission.points_earned)).filter_by(
            user_id=user_id,
            status='approved'
        ).scalar() or 0
        
        # Create certificate record
        certificate = Certificate(
            user_id=user_id,
            internship_field=user.internship_field,
            total_points=total_points,
            total_tasks_completed=completed_tasks
        )
        
        db.session.add(certificate)
        db.session.flush()  # Get the ID
        
        # Generate PDF
        file_path = generate_certificate_pdf(user, certificate, completed_tasks, total_points)
        
        if not file_path:
            db.session.rollback()
            return jsonify({'error': 'Failed to generate certificate PDF'}), 500
        
        certificate.file_path = file_path
        certificate.qr_code_data = f"https://codeops-pro.com/verify/{certificate.certificate_id}"
        
        db.session.commit()
        
        return jsonify({
            'message': 'Certificate generated successfully',
            'certificate': certificate.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@certificate_bp.route('/certificates', methods=['GET'])
@jwt_required()
def get_user_certificates():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        certificates = Certificate.query.filter_by(user_id=user_id).all()
        
        return jsonify({
            'certificates': [cert.to_dict() for cert in certificates]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@certificate_bp.route('/certificates/<int:certificate_id>/download', methods=['GET'])
@jwt_required()
def download_certificate(certificate_id):
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        certificate = Certificate.query.filter_by(
            id=certificate_id,
            user_id=user_id
        ).first()
        
        if not certificate:
            return jsonify({'error': 'Certificate not found'}), 404
        
        if not certificate.file_path:
            return jsonify({'error': 'Certificate file not found'}), 404
        
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], certificate.file_path)
        
        if not os.path.exists(file_path):
            return jsonify({'error': 'Certificate file does not exist'}), 404
        
        return send_file(
            file_path,
            as_attachment=True,
            download_name=f"CodeOps_Pro_Certificate_{certificate.certificate_id}.pdf",
            mimetype='application/pdf'
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@certificate_bp.route('/certificates/verify/<certificate_id>', methods=['GET'])
def verify_certificate(certificate_id):
    try:
        certificate = Certificate.query.filter_by(
            certificate_id=certificate_id,
            is_verified=True
        ).first()
        
        if not certificate:
            return jsonify({'error': 'Certificate not found or invalid'}), 404
        
        user = User.query.get(certificate.user_id)
        
        field_names = {
            'web_dev': 'Web Development',
            'devops': 'DevOps',
            'mobile_dev': 'Mobile App Development'
        }
        
        return jsonify({
            'valid': True,
            'certificate_id': certificate.certificate_id,
            'student_name': user.full_name if user else 'Unknown',
            'internship_field': field_names.get(certificate.internship_field, certificate.internship_field),
            'completion_date': certificate.completion_date.isoformat() if certificate.completion_date else None,
            'total_points': certificate.total_points,
            'total_tasks_completed': certificate.total_tasks_completed
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

