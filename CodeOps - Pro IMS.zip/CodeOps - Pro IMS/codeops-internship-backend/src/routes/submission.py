from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.task import Task
from src.models.submission import Submission
from src.models.user_task_progress import UserTaskProgress
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime

submission_bp = Blueprint("submission", __name__)

ALLOWED_EXTENSIONS = {"txt", "pdf", "png", "jpg", "jpeg", "gif", "doc", "docx", "zip", "py", "js", "html", "css"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@submission_bp.route("/submissions", methods=["POST"])
@jwt_required()
def create_submission():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Get form data
        task_id = request.form.get("task_id")
        submission_text = request.form.get("submission_text", "").strip()
        video_link = request.form.get("video_link", "").strip()
        
        if not task_id:
            return jsonify({"error": "Task ID is required"}), 400
        
        try:
            task_id = int(task_id)
        except ValueError:
            return jsonify({"error": "Invalid task ID"}), 400
        
        # Verify task exists and belongs to user's field
        task = Task.query.filter_by(
            id=task_id,
            internship_field=user.internship_field,
            is_active=True
        ).first()
        
        if not task:
            return jsonify({"error": "Task not found"}), 404
        
        # Check if submission already exists
        existing_submission = Submission.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()
        
        if existing_submission:
            return jsonify({"error": "Submission already exists for this task"}), 400
        
        # Validate that at least one form of submission is provided
        if not submission_text and not video_link and "file" not in request.files:
            return jsonify({"error": "At least one form of submission (text, file, or video link) is required"}), 400
        
        # Handle file upload
        file_path = None
        if "file" in request.files:
            file = request.files["file"]
            if file and file.filename and allowed_file(file.filename):
                # Generate unique filename
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                file_path = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_filename)
                file.save(file_path)
                # Store relative path
                file_path = f"uploads/{unique_filename}"
        
        # Create submission
        submission = Submission(
            user_id=user_id,
            task_id=task_id,
            submission_text=submission_text if submission_text else None,
            file_path=file_path,
            video_link=video_link if video_link else None,
            status="pending"
        )
        
        db.session.add(submission)
        
        # Update UserTaskProgress status to 'submitted'
        user_task_progress = UserTaskProgress.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()

        if user_task_progress:
            user_task_progress.status = "submitted"
            user_task_progress.completed_at = datetime.utcnow()
        else:
            # This case should ideally not happen if task was started correctly
            new_progress = UserTaskProgress(
                user_id=user_id,
                task_id=task_id,
                status="submitted",
                completed_at=datetime.utcnow()
            )
            db.session.add(new_progress)

        db.session.commit()
        
        return jsonify({
            "message": "Submission created successfully",
            "submission": submission.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@submission_bp.route("/submissions/<int:submission_id>", methods=["GET"])
@jwt_required()
def get_submission(submission_id):
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Students can only view their own submissions
        submission = Submission.query.filter_by(
            id=submission_id,
            user_id=user_id
        ).first()
        
        if not submission:
            return jsonify({"error": "Submission not found"}), 404
        
        # Get task details
        task = Task.query.get(submission.task_id)
        submission_dict = submission.to_dict()
        submission_dict["task"] = task.to_dict() if task else None
        
        return jsonify({"submission": submission_dict}), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@submission_bp.route("/submissions", methods=["GET"])
@jwt_required()
def get_user_submissions():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Get all submissions for the user
        submissions = Submission.query.filter_by(user_id=user_id).all()
        
        submission_data = []
        for submission in submissions:
            task = Task.query.get(submission.task_id)
            submission_dict = submission.to_dict()
            submission_dict["task"] = task.to_dict() if task else None
            submission_data.append(submission_dict)
        
        return jsonify({"submissions": submission_data}), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@submission_bp.route("/submissions/<int:submission_id>", methods=["PUT"])
@jwt_required()
def update_submission(submission_id):
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Students can only update their own submissions
        submission = Submission.query.filter_by(
            id=submission_id,
            user_id=user_id
        ).first()
        
        if not submission:
            return jsonify({"error": "Submission not found"}), 404
        
        # Only allow updates if submission is not approved
        if submission.status == "approved":
            return jsonify({"error": "Cannot update approved submission"}), 400
        
        # Update submission fields
        if request.is_json:
            data = request.get_json()
            if "submission_text" in data:
                submission.submission_text = data["submission_text"].strip()
            if "video_link" in data:
                submission.video_link = data["video_link"].strip()
        else:
            # Handle form data
            submission_text = request.form.get("submission_text")
            video_link = request.form.get("video_link")
            
            if submission_text is not None:
                submission.submission_text = submission_text.strip()
            if video_link is not None:
                submission.video_link = video_link.strip()
            
            # Handle file upload
            if "file" in request.files:
                file = request.files["file"]
                if file and file.filename and allowed_file(file.filename):
                    # Remove old file if exists
                    if submission.file_path:
                        old_file_path = os.path.join(current_app.config["UPLOAD_FOLDER"], 
                                                   submission.file_path.replace("uploads/", ""))
                        if os.path.exists(old_file_path):
                            os.remove(old_file_path)
                    
                    # Save new file
                    filename = secure_filename(file.filename)
                    unique_filename = f"{uuid.uuid4()}_{filename}"
                    file_path = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_filename)
                    file.save(file_path)
                    submission.file_path = f"uploads/{unique_filename}"
        
        # Reset status to pending if it was rejected
        if submission.status == "rejected":
            submission.status = "pending"
            submission.admin_feedback = None
        
        # Update UserTaskProgress status to 'submitted' if it was rejected or pending
        user_task_progress = UserTaskProgress.query.filter_by(
            user_id=user_id,
            task_id=submission.task_id
        ).first()

        if user_task_progress:
            user_task_progress.status = "submitted"
            user_task_progress.completed_at = datetime.utcnow()
        else:
            # This case should ideally not happen if task was started correctly
            new_progress = UserTaskProgress(
                user_id=user_id,
                task_id=submission.task_id,
                status="submitted",
                completed_at=datetime.utcnow()
            )
            db.session.add(new_progress)

        db.session.commit()
        
        return jsonify({
            "message": "Submission updated successfully",
            "submission": submission.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


