from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.task import Task
from src.models.submission import Submission
from src.models.user_task_progress import UserTaskProgress
import json
from datetime import datetime

task_bp = Blueprint("task", __name__)

@task_bp.route("/tasks", methods=["GET"])
@jwt_required()
def get_tasks():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        # Get tasks for user's internship field
        tasks = Task.query.filter_by(
            internship_field=user.internship_field,
            is_active=True
        ).order_by(Task.order_index).all()

        # Get user's task progress for these tasks
        task_ids = [task.id for task in tasks]
        user_progresses = UserTaskProgress.query.filter(
            UserTaskProgress.user_id == user_id,
            UserTaskProgress.task_id.in_(task_ids)
        ).all()

        # Create progress lookup
        progress_lookup = {progress.task_id: progress for progress in user_progresses}

        # Prepare task data with progress status
        task_data = []
        for task in tasks:
            task_dict = task.to_dict()
            progress = progress_lookup.get(task.id)

            if progress:
                task_dict["status"] = progress.status
                task_dict["started_at"] = progress.started_at.isoformat() if progress.started_at else None
                task_dict["completed_at"] = progress.completed_at.isoformat() if progress.completed_at else None
            else:
                task_dict["status"] = "not_started"
                task_dict["started_at"] = None
                task_dict["completed_at"] = None

            # Also get submission status if exists
            submission = Submission.query.filter_by(user_id=user_id, task_id=task.id).first()
            if submission:
                task_dict["submission_status"] = submission.status
                task_dict["submission_id"] = submission.id
                task_dict["points_earned"] = submission.points_earned
                task_dict["submitted_at"] = submission.submitted_at.isoformat() if submission.submitted_at else None
                task_dict["admin_feedback"] = submission.admin_feedback
            else:
                task_dict["submission_status"] = "not_submitted"
                task_dict["submission_id"] = None
                task_dict["points_earned"] = 0
                task_dict["submitted_at"] = None
                task_dict["admin_feedback"] = None

            task_data.append(task_dict)

        return jsonify({"tasks": task_data}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route("/tasks/<int:task_id>/start", methods=["POST"])
@jwt_required()
def start_task(task_id):
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        task = Task.query.filter_by(
            id=task_id,
            internship_field=user.internship_field,
            is_active=True
        ).first()

        if not task:
            return jsonify({"error": "Task not found or not assigned to your field"}), 404

        user_task_progress = UserTaskProgress.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()

        if user_task_progress:
            if user_task_progress.status == "not_started":
                user_task_progress.status = "in_progress"
                user_task_progress.started_at = datetime.utcnow()
                db.session.commit()
                return jsonify({"message": "Task started successfully", "status": "in_progress"}), 200
            else:
                return jsonify({"message": f"Task already {user_task_progress.status}"}), 200
        else:
            # Create new progress entry
            new_progress = UserTaskProgress(
                user_id=user_id,
                task_id=task_id,
                status="in_progress",
                started_at=datetime.utcnow()
            )
            db.session.add(new_progress)
            db.session.commit()
            return jsonify({"message": "Task started successfully", "status": "in_progress"}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@task_bp.route("/tasks/<int:task_id>", methods=["GET"])
@jwt_required()
def get_task(task_id):
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        task = Task.query.filter_by(
            id=task_id,
            internship_field=user.internship_field,
            is_active=True
        ).first()

        if not task:
            return jsonify({"error": "Task not found"}), 404

        task_dict = task.to_dict()

        # Get user's task progress for this task
        user_task_progress = UserTaskProgress.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()

        if user_task_progress:
            task_dict["status"] = user_task_progress.status
            task_dict["started_at"] = user_task_progress.started_at.isoformat() if user_task_progress.started_at else None
            task_dict["completed_at"] = user_task_progress.completed_at.isoformat() if user_task_progress.completed_at else None
        else:
            task_dict["status"] = "not_started"
            task_dict["started_at"] = None
            task_dict["completed_at"] = None

        # Also get submission status if exists
        submission = Submission.query.filter_by(user_id=user_id, task_id=task.id).first()
        if submission:
            task_dict["submission_status"] = submission.status
            task_dict["submission_id"] = submission.id
            task_dict["submission_data"] = submission.to_dict()
        else:
            task_dict["submission_status"] = "not_submitted"
            task_dict["submission_id"] = None
            task_dict["submission_data"] = None

        return jsonify({"task": task_dict}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@task_bp.route("/tasks/progress", methods=["GET"])
@jwt_required()
def get_progress():
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        # Get all tasks for user's field
        total_tasks = Task.query.filter_by(
            internship_field=user.internship_field,
            is_active=True
        ).count()

        # Get completed tasks (approved status in UserTaskProgress)
        completed_tasks = UserTaskProgress.query.filter_by(
            user_id=user_id,
            status="approved"
        ).count()

        # Get in-progress tasks
        in_progress_tasks = UserTaskProgress.query.filter_by(
            user_id=user_id,
            status="in_progress"
        ).count()

        # Get submitted tasks
        submitted_tasks = UserTaskProgress.query.filter_by(
            user_id=user_id,
            status="submitted"
        ).count()

        # Get total points earned (from approved submissions)
        total_points = db.session.query(db.func.sum(Submission.points_earned)).filter_by(
            user_id=user_id,
            status="approved"
        ).scalar() or 0

        # Calculate progress percentage
        progress_percentage = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0

        return jsonify({
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "in_progress_tasks": in_progress_tasks,
            "submitted_tasks": submitted_tasks,
            "not_started_tasks": total_tasks - completed_tasks - in_progress_tasks - submitted_tasks,
            "total_points": total_points,
            "progress_percentage": round(progress_percentage, 2),
            "internship_field": user.internship_field
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


