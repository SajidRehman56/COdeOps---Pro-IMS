import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from src.models.user import db
from src.models.task import Task
from src.models.submission import Submission
from src.models.certificate import Certificate
from src.models.user_task_progress import UserTaskProgress
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.task import task_bp
from src.routes.submission import submission_bp
from src.routes.certificate import certificate_bp
from src.routes.admin import admin_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'codeops-pro-internship-secret-key-2024'
app.config['JWT_SECRET_KEY'] = 'jwt-secret-string-codeops-pro'

# Enable CORS for all routes
CORS(app, origins="*")

# Initialize JWT
jwt = JWTManager(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(user_bp, url_prefix="/api")
app.register_blueprint(task_bp, url_prefix="/api")
app.register_blueprint(submission_bp, url_prefix="/api")
app.register_blueprint(certificate_bp, url_prefix="/api")
app.register_blueprint(admin_bp, url_prefix="/api/admin")

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
db.init_app(app)

# Create upload directory
upload_dir = app.config['UPLOAD_FOLDER']
os.makedirs(upload_dir, exist_ok=True)
os.makedirs(os.path.join(upload_dir, 'submissions'), exist_ok=True)
os.makedirs(os.path.join(upload_dir, 'certificates'), exist_ok=True)

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)




@app.route("/health")
def health_check():
    return {"status": "ok"}


