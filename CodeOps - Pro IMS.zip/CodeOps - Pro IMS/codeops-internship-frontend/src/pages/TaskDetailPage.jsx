import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { apiService } from '../lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ArrowLeft,
  Clock,
  Award,
  CheckCircle,
  Upload,
  FileText,
  Link as LinkIcon,
  AlertCircle,
  Play,
  Send
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/use-toast';

const TaskDetailPage = () => {
  const { taskId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState('');
  
  // Submission form state
  const [submissionText, setSubmissionText] = useState('');
  const [videoLink, setVideoLink] = useState('');
  const [file, setFile] = useState(null);

  useEffect(() => {
    fetchTask();
  }, [taskId]);

  const fetchTask = async () => {
    try {
      setLoading(true);
      const response = await apiService.getTask(taskId);
      setTask(response.task);
      
      // Pre-fill form if submission exists
      if (response.task.submission_data) {
        setSubmissionText(response.task.submission_data.submission_text || '');
        setVideoLink(response.task.submission_data.video_link || '');
      }
    } catch (err) {
      setError('Failed to load task details');
      console.error('Task fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTask = async () => {
    try {
      setStarting(true);
      await apiService.startTask(taskId);
      
      toast({
        title: "Task Started",
        description: "You can now work on this task and submit your solution.",
      });
      
      // Refresh task data
      await fetchTask();
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to start task",
        variant: "destructive",
      });
    } finally {
      setStarting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!submissionText.trim() && !videoLink.trim() && !file) {
      toast({
        title: "Error",
        description: "Please provide at least one form of submission (text, file, or video link).",
        variant: "destructive",
      });
      return;
    }

    try {
      setSubmitting(true);
      
      const formData = new FormData();
      formData.append('task_id', taskId);
      formData.append('submission_text', submissionText.trim());
      formData.append('video_link', videoLink.trim());
      
      if (file) {
        formData.append('file', file);
      }

      if (task.submission_data) {
        // Update existing submission
        await apiService.updateSubmission(task.submission_data.id, formData);
        toast({
          title: "Submission Updated",
          description: "Your submission has been updated successfully.",
        });
      } else {
        // Create new submission
        await apiService.createSubmission(formData);
        toast({
          title: "Submission Created",
          description: "Your submission has been submitted for review.",
        });
      }
      
      // Refresh task data
      await fetchTask();
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to submit work",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'submitted':
        return 'bg-blue-500';
      case 'in_progress':
        return 'bg-yellow-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4" />;
      case 'submitted':
        return <Upload className="h-4 w-4" />;
      case 'in_progress':
        return <Clock className="h-4 w-4" />;
      case 'rejected':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'approved':
        return 'Completed';
      case 'submitted':
        return 'Under Review';
      case 'in_progress':
        return 'In Progress';
      case 'rejected':
        return 'Needs Revision';
      default:
        return 'Not Started';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error || !task) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center py-12">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
              {error || 'Task not found'}
            </h2>
            <Link to="/dashboard">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const canSubmit = task.status === 'in_progress' || task.status === 'rejected';
  const isCompleted = task.status === 'approved';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                {task.title}
              </h1>
              <div className="flex items-center space-x-4 mt-2">
                <Badge className={`${getStatusColor(task.status)} text-white`}>
                  {getStatusIcon(task.status)}
                  <span className="ml-2">{getStatusText(task.status)}</span>
                </Badge>
                <span className="text-sm text-slate-500 dark:text-slate-400">
                  {task.points} points • {task.estimated_hours}h estimated
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Task Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Task Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose dark:prose-invert max-w-none">
                  <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                    {task.description}
                  </p>
                </div>
              </CardContent>
            </Card>

            {task.requirements && (
              <Card>
                <CardHeader>
                  <CardTitle>Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose dark:prose-invert max-w-none">
                    <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {task.requirements}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {task.resources && (
              <Card>
                <CardHeader>
                  <CardTitle>Resources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose dark:prose-invert max-w-none">
                    <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {task.resources}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Admin Feedback */}
            {task.admin_feedback && task.status === 'rejected' && (
              <Card className="border-red-200 dark:border-red-800">
                <CardHeader>
                  <CardTitle className="text-red-800 dark:text-red-200">
                    Feedback from Instructor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-red-700 dark:text-red-300">
                    {task.admin_feedback}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Submission Panel */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Task Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${getStatusColor(task.status)}`}>
                    {getStatusIcon(task.status)}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">
                      {getStatusText(task.status)}
                    </p>
                    {task.started_at && (
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Started: {new Date(task.started_at).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>

                {task.status === 'not_started' && (
                  <Button 
                    onClick={handleStartTask} 
                    disabled={starting}
                    className="w-full"
                  >
                    {starting ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Start Task
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Submission Form */}
            {canSubmit && (
              <Card>
                <CardHeader>
                  <CardTitle>
                    {task.submission_data ? 'Update Submission' : 'Submit Your Work'}
                  </CardTitle>
                  <CardDescription>
                    Provide at least one form of submission
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="submission_text">Description/Notes</Label>
                      <Textarea
                        id="submission_text"
                        placeholder="Describe your solution, approach, or any notes..."
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        rows={4}
                      />
                    </div>

                    <div>
                      <Label htmlFor="video_link">Video Link (Optional)</Label>
                      <Input
                        id="video_link"
                        type="url"
                        placeholder="https://youtube.com/watch?v=..."
                        value={videoLink}
                        onChange={(e) => setVideoLink(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="file">Upload File (Optional)</Label>
                      <Input
                        id="file"
                        type="file"
                        onChange={(e) => setFile(e.target.files[0])}
                        accept=".txt,.pdf,.png,.jpg,.jpeg,.gif,.doc,.docx,.zip,.py,.js,.html,.css"
                      />
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Supported formats: txt, pdf, images, documents, code files, zip
                      </p>
                    </div>

                    <Button type="submit" disabled={submitting} className="w-full">
                      {submitting ? (
                        <LoadingSpinner size="sm" />
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          {task.submission_data ? 'Update Submission' : 'Submit Work'}
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            )}

            {/* View Submission */}
            {task.submission_data && (
              <Card>
                <CardHeader>
                  <CardTitle>Your Submission</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {task.submission_data.submission_text && (
                    <div>
                      <Label>Description/Notes:</Label>
                      <p className="text-sm text-slate-700 dark:text-slate-300 mt-1 p-2 bg-slate-50 dark:bg-slate-800 rounded">
                        {task.submission_data.submission_text}
                      </p>
                    </div>
                  )}

                  {task.submission_data.video_link && (
                    <div>
                      <Label>Video Link:</Label>
                      <a 
                        href={task.submission_data.video_link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 dark:text-blue-400 hover:underline text-sm flex items-center mt-1"
                      >
                        <LinkIcon className="h-4 w-4 mr-1" />
                        View Video
                      </a>
                    </div>
                  )}

                  {task.submission_data.file_path && (
                    <div>
                      <Label>Uploaded File:</Label>
                      <p className="text-sm text-slate-700 dark:text-slate-300 mt-1">
                        File uploaded successfully
                      </p>
                    </div>
                  )}

                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    Submitted: {new Date(task.submission_data.submitted_at).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Completion Badge */}
            {isCompleted && (
              <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-2" />
                    <h3 className="font-semibold text-green-800 dark:text-green-200">
                      Task Completed!
                    </h3>
                    <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                      You earned {task.points_earned || task.points} points
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskDetailPage;

