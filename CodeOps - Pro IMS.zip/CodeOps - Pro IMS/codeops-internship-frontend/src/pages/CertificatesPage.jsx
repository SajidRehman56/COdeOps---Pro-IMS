import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { apiService } from '../lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft,
  Award,
  Download,
  CheckCircle,
  Calendar,
  Trophy,
  Star,
  FileText,
  QrCode,
  AlertCircle
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/use-toast';

const CertificatesPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [certificates, setCertificates] = useState([]);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [downloading, setDownloading] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [certificatesResponse, progressResponse] = await Promise.all([
        apiService.getCertificates(),
        apiService.getProgress()
      ]);
      
      setCertificates(certificatesResponse.certificates || []);
      setProgress(progressResponse);
    } catch (err) {
      setError('Failed to load certificates data');
      console.error('Certificates fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateCertificate = async () => {
    try {
      setGenerating(true);
      await apiService.generateCertificate();
      
      toast({
        title: "Certificate Generated!",
        description: "Your certificate has been generated successfully.",
      });
      
      // Refresh certificates
      await fetchData();
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to generate certificate",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadCertificate = async (certificateId, certificateNumber) => {
    try {
      setDownloading(certificateId);
      const blob = await apiService.downloadCertificate(certificateId);
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `CodeOps_Pro_Certificate_${certificateNumber}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Download Started",
        description: "Your certificate is being downloaded.",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to download certificate",
        variant: "destructive",
      });
    } finally {
      setDownloading(null);
    }
  };

  const fieldNames = {
    'web_dev': 'Web Development',
    'devops': 'DevOps',
    'mobile_dev': 'Mobile App Development'
  };

  const canGenerateCertificate = progress && progress.progress_percentage === 100 && certificates.length === 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                Certificates
              </h1>
              <p className="text-slate-600 dark:text-slate-300 mt-1">
                Your internship completion certificates
              </p>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-red-800 dark:text-red-200">{error}</p>
          </div>
        )}

        {/* Progress Overview */}
        {progress && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Trophy className="h-5 w-5 mr-2" />
                Your Progress
              </CardTitle>
              <CardDescription>
                {fieldNames[user?.internship_field]} Internship Program
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {progress.completed_tasks}
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    Tasks Completed
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {progress.total_points}
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    Points Earned
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {progress.progress_percentage.toFixed(0)}%
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    Progress
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {certificates.length}
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    Certificates
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Generate Certificate Section */}
        {canGenerateCertificate && (
          <Card className="mb-8 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950 border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle className="flex items-center text-green-900 dark:text-green-100">
                <Award className="h-5 w-5 mr-2" />
                Congratulations!
              </CardTitle>
              <CardDescription className="text-green-700 dark:text-green-300">
                You've completed all tasks in the {fieldNames[user?.internship_field]} program. 
                Generate your certificate now!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={handleGenerateCertificate}
                disabled={generating}
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
              >
                {generating ? (
                  <LoadingSpinner size="sm" />
                ) : (
                  <>
                    <Award className="h-4 w-4 mr-2" />
                    Generate Certificate
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Certificates List */}
        {certificates.length > 0 ? (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
              Your Certificates
            </h2>
            
            {certificates.map((certificate) => (
              <Card key={certificate.id} className="overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center text-blue-900 dark:text-blue-100">
                        <Award className="h-5 w-5 mr-2" />
                        {fieldNames[certificate.internship_field]} Certificate
                      </CardTitle>
                      <CardDescription className="text-blue-700 dark:text-blue-300 mt-2">
                        Certificate ID: {certificate.certificate_id}
                      </CardDescription>
                    </div>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Verified
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Calendar className="h-4 w-4 text-slate-500" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            Completion Date
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            {new Date(certificate.completion_date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Star className="h-4 w-4 text-slate-500" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            Points Earned
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            {certificate.total_points} points
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <FileText className="h-4 w-4 text-slate-500" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            Tasks Completed
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            {certificate.total_tasks_completed} tasks
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <QrCode className="h-4 w-4 text-slate-500" />
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            Verification
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            QR code included for authenticity
                          </p>
                        </div>
                      </div>
                      
                      <div className="pt-4">
                        <Button 
                          onClick={() => handleDownloadCertificate(certificate.id, certificate.certificate_id)}
                          disabled={downloading === certificate.id}
                          className="w-full"
                        >
                          {downloading === certificate.id ? (
                            <LoadingSpinner size="sm" />
                          ) : (
                            <>
                              <Download className="h-4 w-4 mr-2" />
                              Download Certificate
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : !canGenerateCertificate && (
          <Card>
            <CardContent className="text-center py-12">
              <Award className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                No Certificates Yet
              </h3>
              {progress && progress.progress_percentage < 100 ? (
                <div>
                  <p className="text-slate-600 dark:text-slate-300 mb-4">
                    Complete all tasks in your internship program to earn your certificate.
                  </p>
                  <div className="max-w-md mx-auto">
                    <div className="flex justify-between text-sm text-slate-600 dark:text-slate-300 mb-2">
                      <span>Progress</span>
                      <span>{progress.progress_percentage.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress.progress_percentage}%` }}
                      ></div>
                    </div>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                      {progress.completed_tasks} of {progress.total_tasks} tasks completed
                    </p>
                  </div>
                  <Link to="/dashboard" className="mt-6 inline-block">
                    <Button>
                      Continue Learning
                    </Button>
                  </Link>
                </div>
              ) : (
                <p className="text-slate-600 dark:text-slate-300">
                  Your certificates will appear here once generated.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Information Section */}
        <Card className="mt-8 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="text-blue-900 dark:text-blue-100">
              About Your Certificate
            </CardTitle>
          </CardHeader>
          <CardContent className="text-blue-800 dark:text-blue-200">
            <ul className="space-y-2 text-sm">
              <li className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Certificates are automatically generated upon completion of all tasks</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Each certificate includes a unique QR code for verification</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>Certificates are available as downloadable PDF files</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>All certificates are digitally signed and verified by CodeOps Pro</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CertificatesPage;

