import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { apiService } from '../lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Users, 
  FileText, 
  CheckCircle, 
  Clock, 
  Award, 
  LogOut,
  Eye,
  ThumbsUp,
  ThumbsDown,
  AlertCircle,
  BookOpen,
  TrendingUp,
  UserCheck,
  FileCheck,
  Target,
  Plus,
  Edit,
  Trash2
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/use-toast';

const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  
  const [dashboardData, setDashboardData] = useState(null);
  const [students, setStudents] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submissionsLoading, setSubmissionsLoading] = useState(false);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [reviewingSubmission, setReviewingSubmission] = useState(null);
  const [reviewFeedback, setReviewFeedback] = useState('');
  const [selectedField, setSelectedField] = useState('all');
  const [showCreateTaskDialog, setShowCreateTaskDialog] = useState(false);
  const [creatingTask, setCreatingTask] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    internship_field: '',
    difficulty_level: 'beginner',
    order_index: 1,
    points: 10,
    estimated_hours: 1,
    requirements: '',
    resources: ''
  });

  useEffect(() => {
    fetchDashboardData();
    fetchStudents();
    fetchSubmissions();
    fetchTasks();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await apiService.getAdminDashboard();
      setDashboardData(response);
    } catch (err) {
      console.error('Dashboard fetch error:', err);
    }
  };

  const fetchStudents = async () => {
    try {
      const params = selectedField !== 'all' ? { field: selectedField } : {};
      const response = await apiService.getStudents(params);
      setStudents(response.students || []);
    } catch (err) {
      console.error('Students fetch error:', err);
    }
  };

  const fetchSubmissions = async () => {
    try {
      setSubmissionsLoading(true);
      const params = selectedField !== 'all' ? { field: selectedField } : {};
      const response = await apiService.getAllSubmissions(params);
      setSubmissions(response.submissions || []);
    } catch (err) {
      console.error('Submissions fetch error:', err);
    } finally {
      setSubmissionsLoading(false);
      setLoading(false);
    }
  };

  const fetchTasks = async () => {
    try {
      setTasksLoading(true);
      const params = selectedField !== 'all' ? { field: selectedField } : {};
      const response = await apiService.getAllTasks(params);
      setTasks(response.tasks || []);
    } catch (err) {
      console.error('Tasks fetch error:', err);
    } finally {
      setTasksLoading(false);
    }
  };

  const handleCreateTask = async () => {
    try {
      setCreatingTask(true);
      
      // Validate required fields
      if (!newTask.title || !newTask.description || !newTask.internship_field) {
        toast({
          title: "Error",
          description: "Please fill in all required fields",
          variant: "destructive",
        });
        return;
      }

      await apiService.createTask(newTask);
      
      toast({
        title: "Task Created",
        description: "New task has been created successfully.",
      });

      // Reset form and close dialog
      setNewTask({
        title: '',
        description: '',
        internship_field: '',
        difficulty_level: 'beginner',
        order_index: 1,
        points: 10,
        estimated_hours: 1,
        requirements: '',
        resources: ''
      });
      setShowCreateTaskDialog(false);
      
      // Refresh data
      await Promise.all([
        fetchDashboardData(),
        fetchTasks()
      ]);
      
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to create task",
        variant: "destructive",
      });
    } finally {
      setCreatingTask(false);
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      await apiService.deleteTask(taskId);
      
      toast({
        title: "Task Deleted",
        description: "Task has been deleted successfully.",
      });
      
      // Refresh data
      await Promise.all([
        fetchDashboardData(),
        fetchTasks()
      ]);
      
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to delete task",
        variant: "destructive",
      });
    }
  };

  const handleReviewSubmission = async (submissionId, status) => {
    try {
      setReviewingSubmission(submissionId);
      
      const reviewData = {
        status,
        feedback: reviewFeedback.trim()
      };

      await apiService.reviewSubmission(submissionId, reviewData);
      
      toast({
        title: "Submission Reviewed",
        description: `Submission has been ${status}.`,
      });

      // Refresh data
      await Promise.all([
        fetchDashboardData(),
        fetchStudents(),
        fetchSubmissions()
      ]);
      
      setReviewFeedback('');
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to review submission",
        variant: "destructive",
      });
    } finally {
      setReviewingSubmission(null);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'pending':
        return 'bg-yellow-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4" />;
      case 'pending':
        return <Clock className="h-4 w-4" />;
      case 'rejected':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const fieldNames = {
    'web_dev': 'Web Development',
    'devops': 'DevOps',
    'mobile_dev': 'Mobile App Development'
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
                  CodeOps Pro Admin
                </h1>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Internship Management System
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-slate-600 dark:text-slate-300">
                Welcome, {user?.full_name}
              </span>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Overview */}
        {dashboardData && (
          <div className="grid md:grid-cols-5 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Total Students
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {dashboardData.total_students}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Total Tasks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {dashboardData.total_tasks}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Pending Reviews
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  {dashboardData.pending_submissions}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Approved Tasks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {dashboardData.approved_submissions}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Certificates Issued
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  {dashboardData.total_certificates}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Field Filter */}
        <div className="mb-6">
          <div className="flex space-x-2">
            <Button
              variant={selectedField === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setSelectedField('all');
                fetchStudents();
                fetchSubmissions();
                fetchTasks();
              }}
            >
              All Fields
            </Button>
            {Object.entries(fieldNames).map(([key, name]) => (
              <Button
                key={key}
                variant={selectedField === key ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setSelectedField(key);
                  fetchStudents();
                  fetchSubmissions();
                  fetchTasks();
                }}
              >
                {name}
              </Button>
            ))}
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="submissions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="submissions">Submissions Review</TabsTrigger>
            <TabsTrigger value="students">Student Management</TabsTrigger>
            <TabsTrigger value="tasks">Task Management</TabsTrigger>
            <TabsTrigger value="overview">Field Overview</TabsTrigger>
          </TabsList>

          {/* Submissions Review Tab */}
          <TabsContent value="submissions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileCheck className="h-5 w-5 mr-2" />
                  Submissions Review
                </CardTitle>
                <CardDescription>
                  Review and approve student submissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {submissionsLoading ? (
                  <div className="flex justify-center py-8">
                    <LoadingSpinner size="lg" />
                  </div>
                ) : submissions.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-500 dark:text-slate-400">No submissions found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {submissions.map((submission) => (
                      <div
                        key={submission.id}
                        className="border border-slate-200 dark:border-slate-700 rounded-lg p-4"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs ${getStatusColor(submission.status)}`}>
                                {getStatusIcon(submission.status)}
                              </div>
                              <div>
                                <h3 className="font-medium text-slate-900 dark:text-white">
                                  {submission.task?.title || 'Unknown Task'}
                                </h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400">
                                  by {submission.user?.full_name || 'Unknown User'} • 
                                  {fieldNames[submission.user?.internship_field] || 'Unknown Field'}
                                </p>
                              </div>
                            </div>

                            {submission.submission_text && (
                              <div className="mb-3">
                                <Label className="text-xs text-slate-500 dark:text-slate-400">
                                  Submission Text:
                                </Label>
                                <p className="text-sm text-slate-700 dark:text-slate-300 mt-1 p-2 bg-slate-50 dark:bg-slate-800 rounded">
                                  {submission.submission_text}
                                </p>
                              </div>
                            )}

                            {submission.video_link && (
                              <div className="mb-3">
                                <Label className="text-xs text-slate-500 dark:text-slate-400">
                                  Video Link:
                                </Label>
                                <a 
                                  href={submission.video_link} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-blue-600 dark:text-blue-400 hover:underline text-sm block mt-1"
                                >
                                  {submission.video_link}
                                </a>
                              </div>
                            )}

                            {submission.file_path && (
                              <div className="mb-3">
                                <Label className="text-xs text-slate-500 dark:text-slate-400">
                                  File:
                                </Label>
                                <p className="text-sm text-slate-700 dark:text-slate-300 mt-1">
                                  File uploaded
                                </p>
                              </div>
                            )}

                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              Submitted: {new Date(submission.submitted_at).toLocaleString()}
                            </div>
                          </div>

                          {submission.status === 'pending' && (
                            <div className="ml-4 space-y-3 min-w-[300px]">
                              <div>
                                <Label htmlFor={`feedback-${submission.id}`}>
                                  Feedback (Optional)
                                </Label>
                                <Textarea
                                  id={`feedback-${submission.id}`}
                                  placeholder="Provide feedback to the student..."
                                  value={reviewingSubmission === submission.id ? reviewFeedback : ''}
                                  onChange={(e) => {
                                    if (reviewingSubmission === submission.id) {
                                      setReviewFeedback(e.target.value);
                                    }
                                  }}
                                  onFocus={() => setReviewingSubmission(submission.id)}
                                  rows={3}
                                />
                              </div>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  onClick={() => handleReviewSubmission(submission.id, 'approved')}
                                  disabled={reviewingSubmission && reviewingSubmission !== submission.id}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <ThumbsUp className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleReviewSubmission(submission.id, 'rejected')}
                                  disabled={reviewingSubmission && reviewingSubmission !== submission.id}
                                >
                                  <ThumbsDown className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            </div>
                          )}

                          {submission.status !== 'pending' && (
                            <div className="ml-4">
                              <Badge variant={submission.status === 'approved' ? 'default' : 'destructive'}>
                                {submission.status}
                              </Badge>
                              {submission.admin_feedback && (
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-[200px]">
                                  Feedback: {submission.admin_feedback}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Student Management Tab */}
          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserCheck className="h-5 w-5 mr-2" />
                  Student Management
                </CardTitle>
                <CardDescription>
                  Monitor student progress and performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                {students.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-500 dark:text-slate-400">No students found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {students.map((student) => (
                      <div
                        key={student.id}
                        className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium">
                            {student.full_name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-medium text-slate-900 dark:text-white">
                              {student.full_name}
                            </h3>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                              {student.email} • {fieldNames[student.internship_field]}
                            </p>
                            <p className="text-xs text-slate-400 dark:text-slate-500">
                              Joined: {new Date(student.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center space-x-4 mb-2">
                            <div className="text-center">
                              <div className="text-lg font-bold text-green-600">
                                {student.progress?.completed_tasks || 0}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                Completed
                              </div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-yellow-600">
                                {student.progress?.in_progress_tasks || 0}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                In Progress
                              </div>
                            </div>
                            <div className="text-center">
                              <div className="text-lg font-bold text-blue-600">
                                {student.progress?.total_points || 0}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                Points
                              </div>
                            </div>
                          </div>
                          <div className="text-sm text-slate-600 dark:text-slate-300">
                            Progress: {student.progress?.progress_percentage?.toFixed(0) || 0}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Task Management Tab */}
          <TabsContent value="tasks">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Target className="h-5 w-5 mr-2" />
                      Task Management
                    </CardTitle>
                    <CardDescription>
                      Create, edit, and manage tasks for different internship fields
                    </CardDescription>
                  </div>
                  <Dialog open={showCreateTaskDialog} onOpenChange={setShowCreateTaskDialog}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Task
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create New Task</DialogTitle>
                        <DialogDescription>
                          Add a new task to the internship program
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="task-title">Title *</Label>
                            <Input
                              id="task-title"
                              value={newTask.title}
                              onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                              placeholder="Enter task title"
                            />
                          </div>
                          <div>
                            <Label htmlFor="task-field">Internship Field *</Label>
                            <Select value={newTask.internship_field} onValueChange={(value) => setNewTask({...newTask, internship_field: value})}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select field" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="web_dev">Web Development</SelectItem>
                                <SelectItem value="devops">DevOps</SelectItem>
                                <SelectItem value="mobile_dev">Mobile App Development</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="task-description">Description *</Label>
                          <Textarea
                            id="task-description"
                            value={newTask.description}
                            onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                            placeholder="Enter task description"
                            rows={4}
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor="task-difficulty">Difficulty Level</Label>
                            <Select value={newTask.difficulty_level} onValueChange={(value) => setNewTask({...newTask, difficulty_level: value})}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="beginner">Beginner</SelectItem>
                                <SelectItem value="intermediate">Intermediate</SelectItem>
                                <SelectItem value="advanced">Advanced</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="task-points">Points</Label>
                            <Input
                              id="task-points"
                              type="number"
                              value={newTask.points}
                              onChange={(e) => setNewTask({...newTask, points: parseInt(e.target.value) || 10})}
                              min="1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="task-hours">Estimated Hours</Label>
                            <Input
                              id="task-hours"
                              type="number"
                              value={newTask.estimated_hours}
                              onChange={(e) => setNewTask({...newTask, estimated_hours: parseInt(e.target.value) || 1})}
                              min="1"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="task-order">Order Index</Label>
                          <Input
                            id="task-order"
                            type="number"
                            value={newTask.order_index}
                            onChange={(e) => setNewTask({...newTask, order_index: parseInt(e.target.value) || 1})}
                            min="1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="task-requirements">Requirements (Optional)</Label>
                          <Textarea
                            id="task-requirements"
                            value={newTask.requirements}
                            onChange={(e) => setNewTask({...newTask, requirements: e.target.value})}
                            placeholder="Enter task requirements"
                            rows={3}
                          />
                        </div>
                        <div>
                          <Label htmlFor="task-resources">Resources (Optional)</Label>
                          <Textarea
                            id="task-resources"
                            value={newTask.resources}
                            onChange={(e) => setNewTask({...newTask, resources: e.target.value})}
                            placeholder="Enter helpful resources"
                            rows={3}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowCreateTaskDialog(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleCreateTask} disabled={creatingTask}>
                          {creatingTask ? <LoadingSpinner size="sm" /> : 'Create Task'}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {tasksLoading ? (
                  <div className="flex justify-center py-8">
                    <LoadingSpinner size="lg" />
                  </div>
                ) : tasks.length === 0 ? (
                  <div className="text-center py-8">
                    <Target className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-500 dark:text-slate-400">No tasks found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {tasks.map((task) => (
                      <div
                        key={task.id}
                        className="border border-slate-200 dark:border-slate-700 rounded-lg p-4"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <Badge variant={task.difficulty_level === 'advanced' ? 'destructive' : task.difficulty_level === 'intermediate' ? 'default' : 'secondary'}>
                                {task.difficulty_level}
                              </Badge>
                              <Badge variant="outline">
                                {fieldNames[task.internship_field]}
                              </Badge>
                              <Badge variant="outline">
                                Order: {task.order_index}
                              </Badge>
                            </div>
                            <h3 className="font-medium text-slate-900 dark:text-white mb-1">
                              {task.title}
                            </h3>
                            <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                              {task.description}
                            </p>
                            <div className="flex items-center space-x-4 text-xs text-slate-500 dark:text-slate-400">
                              <span>{task.points} points</span>
                              <span>{task.estimated_hours}h estimated</span>
                              <span>Created: {new Date(task.created_at).toLocaleDateString()}</span>
                              <span className={task.is_active ? 'text-green-600' : 'text-red-600'}>
                                {task.is_active ? 'Active' : 'Inactive'}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 ml-4">
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteTask(task.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Field Overview Tab */}
          <TabsContent value="overview">
            <div className="grid md:grid-cols-3 gap-6">
              {dashboardData?.field_statistics && Object.entries(dashboardData.field_statistics).map(([field, stats]) => (
                <Card key={field}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Target className="h-5 w-5 mr-2" />
                      {fieldNames[field]}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-slate-600 dark:text-slate-300">Students:</span>
                      <span className="font-semibold">{stats.students}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600 dark:text-slate-300">Tasks:</span>
                      <span className="font-semibold">{stats.tasks}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Activity */}
            {dashboardData?.recent_submissions && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {dashboardData.recent_submissions.map((submission) => (
                      <div key={submission.id} className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700 last:border-0">
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">
                            {submission.user_name} submitted "{submission.task_title}"
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {new Date(submission.submitted_at).toLocaleString()}
                          </p>
                        </div>
                        <Badge variant={submission.status === 'approved' ? 'default' : 'secondary'}>
                          {submission.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;

