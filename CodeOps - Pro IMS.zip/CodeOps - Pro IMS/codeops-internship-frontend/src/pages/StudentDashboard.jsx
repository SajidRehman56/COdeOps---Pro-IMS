import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { apiService } from '../lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  CheckCircle, 
  Clock, 
  Award, 
  User, 
  LogOut,
  Trophy,
  Target,
  FileText,
  Play,
  Upload,
  AlertCircle
} from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/use-toast';

const StudentDashboard = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [tasks, setTasks] = useState([]);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [startingTask, setStartingTask] = useState(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [tasksResponse, progressResponse] = await Promise.all([
        apiService.getTasks(),
        apiService.getProgress()
      ]);
      
      setTasks(tasksResponse.tasks || []);
      setProgress(progressResponse);
    } catch (err) {
      setError('Failed to load dashboard data');
      console.error('Dashboard error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTask = async (taskId) => {
    try {
      setStartingTask(taskId);
      await apiService.startTask(taskId);
      
      toast({
        title: "Task Started",
        description: "You can now work on this task and submit your solution.",
      });
      
      // Refresh data to show updated status
      await fetchDashboardData();
    } catch (err) {
      toast({
        title: "Error",
        description: err.message || "Failed to start task",
        variant: "destructive",
      });
    } finally {
      setStartingTask(null);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'submitted':
        return 'bg-blue-500';
      case 'in_progress':
        return 'bg-yellow-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4" />;
      case 'submitted':
        return <Upload className="h-4 w-4" />;
      case 'in_progress':
        return <Clock className="h-4 w-4" />;
      case 'rejected':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <BookOpen className="h-4 w-4" />;
    }
  };

  const getStatusText = (task) => {
    if (task.status === 'approved') return 'Completed';
    if (task.status === 'submitted') return 'Under Review';
    if (task.status === 'in_progress') return 'In Progress';
    if (task.status === 'rejected') return 'Needs Revision';
    return 'Not Started';
  };

  const getTaskAction = (task) => {
    if (task.status === 'approved') {
      return { text: 'View', variant: 'outline' };
    }
    if (task.status === 'submitted') {
      return { text: 'View Submission', variant: 'outline' };
    }
    if (task.status === 'in_progress' || task.status === 'rejected') {
      return { text: 'Submit Work', variant: 'default' };
    }
    return { text: 'Start Task', variant: 'default' };
  };

  const fieldNames = {
    'web_dev': 'Web Development',
    'devops': 'DevOps',
    'mobile_dev': 'Mobile App Development'
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
                  CodeOps Pro
                </h1>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  {fieldNames[user?.internship_field] || 'Student Dashboard'}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link to="/profile">
                <Button variant="ghost" size="sm">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Link to="/certificates">
                <Button variant="ghost" size="sm">
                  <Award className="h-4 w-4 mr-2" />
                  Certificates
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
            Welcome back, {user?.full_name}!
          </h2>
          <p className="text-slate-600 dark:text-slate-300">
            Continue your {fieldNames[user?.internship_field]} journey
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-red-800 dark:text-red-200">{error}</p>
          </div>
        )}

        {/* Progress Overview */}
        {progress && (
          <div className="grid md:grid-cols-5 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Total Tasks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {progress.total_tasks}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Completed
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {progress.completed_tasks}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  In Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  {progress.in_progress_tasks}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Points Earned
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {progress.total_points}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600 mb-2">
                  {progress.progress_percentage.toFixed(0)}%
                </div>
                <Progress value={progress.progress_percentage} className="h-2" />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Tasks List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-5 w-5 mr-2" />
              Your Tasks
            </CardTitle>
            <CardDescription>
              Complete tasks in order to progress through your internship
            </CardDescription>
          </CardHeader>
          <CardContent>
            {tasks.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400">No tasks available</p>
              </div>
            ) : (
              <div className="space-y-4">
                {tasks.map((task, index) => {
                  const action = getTaskAction(task);
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${getStatusColor(task.status)}`}>
                          {getStatusIcon(task.status)}
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-900 dark:text-white">
                            {task.title}
                          </h3>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            {task.points} points • {task.estimated_hours}h estimated
                          </p>
                          {task.admin_feedback && task.status === 'rejected' && (
                            <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                              Feedback: {task.admin_feedback}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Badge variant={task.status === 'approved' ? 'default' : 'secondary'}>
                          {getStatusText(task)}
                        </Badge>
                        
                        {task.status === 'not_started' ? (
                          <Button 
                            size="sm" 
                            onClick={() => handleStartTask(task.id)}
                            disabled={startingTask === task.id}
                          >
                            {startingTask === task.id ? (
                              <LoadingSpinner size="sm" />
                            ) : (
                              <>
                                <Play className="h-4 w-4 mr-2" />
                                Start Task
                              </>
                            )}
                          </Button>
                        ) : (
                          <Link to={`/tasks/${task.id}`}>
                            <Button size="sm" variant={action.variant}>
                              {action.text}
                            </Button>
                          </Link>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Certificate Section */}
        {progress && progress.progress_percentage === 100 && (
          <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-900 dark:text-blue-100">
                <Trophy className="h-5 w-5 mr-2" />
                Congratulations!
              </CardTitle>
              <CardDescription className="text-blue-700 dark:text-blue-300">
                You've completed all tasks. Generate your certificate now!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/certificates">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  <Award className="h-4 w-4 mr-2" />
                  Get Certificate
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;

